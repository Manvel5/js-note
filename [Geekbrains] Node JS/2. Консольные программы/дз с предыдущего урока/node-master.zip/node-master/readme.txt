Telegram bot on node.js server.

Use:

1. Join to https://web.telegram.org/#/im?p=@VahtaBot
2. Run index.js
