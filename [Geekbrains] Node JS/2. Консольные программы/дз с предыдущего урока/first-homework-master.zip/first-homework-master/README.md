# Have a nice day!

There is a console application that gives you current weather, forecast for tomorrow and a funny random joke. Celcius or Fahrenheit degrees are optional, Celsius is default.

## Start application
Clone the repository, open the folder with the project in your terminal.
Type `node index.js`.

## Use application
Type in city and country where you live or any other cities that you just like.
Admitted type formats:
+ first letter for degree scale and city is allowed both in lower in upper cases
  - for example, both `paris` and `Paris` give the same result
+ country or region are optional, but it could guarantee more accuracy 
+ city and country should be divided by comma and space, otherwise your inputed text will be considered as one word
  - for example, `paris, france` is not the same as `paris france` or `paris,france`

We use [weather-js](https://www.npmjs.com/package/weather-js), you can read more about them if you like.