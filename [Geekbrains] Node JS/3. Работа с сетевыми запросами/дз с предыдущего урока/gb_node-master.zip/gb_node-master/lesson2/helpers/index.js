module.exports = {
  isAnswerYes: answer => answer === 'y' || answer === 'Y',
  isAnswerNo: answer => answer === 'n' || answer === 'N'
}
