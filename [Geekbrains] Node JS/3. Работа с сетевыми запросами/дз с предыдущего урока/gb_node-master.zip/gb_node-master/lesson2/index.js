const bj = require('./lib/bj')

bj.start()
